package com.mycompany.seniordesign

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
