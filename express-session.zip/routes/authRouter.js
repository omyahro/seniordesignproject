const express = require('express')
const path = require("path")
const router = express.Router()


router.get('/', (req, res)=>{
    res.sendFile(path.join(__dirname,"..", "public", "html", "login.html"))
})

router.post('/', (req, res)=>{
    let email = req.body.username
    let password = req.body.password

    if(email== "test@cau.edu" && password=='123456'){
        req.session.isAuth = true
        req.session.uname = "Test User"
        console.log("Authenticated user:"+ req.session.uname)
        res.redirect("/u/profile")
    }else{
        req.session.isAuth = false
        res.json({"msg":"Authentication Failed! Try later"})
    }

})

module.exports = router