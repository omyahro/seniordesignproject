const express = require('express')
const path = require("path")
const router = express.Router()

router.get("/profile", (req, res)=>{
    if(!req.session.isAuth){
        res.redirect('/auth')
    }else{
        res.render('pages/profile', {username: req.session.uname})
    }

})


module.exports = router