const express = require("express")
const {expires} = require("express-session/session/cookie");
const path = require("path")
const session = require("express-session")
const {randomUUID} = require("crypto")

const app = express()

app.set("view engine", "ejs")

app.use(session({
    genid:(req)=>{
        return randomUUID()
    },
    secret: 'flKmcrF9cA@lmn230o9(32',
    saveUninitialized: false,
    resave:true
}))

app.use('/public', express.static('public'))
app.use(express.urlencoded({extended:true}))

var userRouter = require('./routes/usersRouter')
var authRouter = require('./routes/authRouter')

app.use('/u', userRouter)
app.use('/auth', authRouter)


app.get('/', (req, res)=>{
    res.sendFile(path.join(__dirname, "public", "html", "home.html"))
})


app.use((req, res)=>{
    res.status(404)
})

app.listen(3000, ()=>{
    console.log("Server is running at http://localhost:3000")
})