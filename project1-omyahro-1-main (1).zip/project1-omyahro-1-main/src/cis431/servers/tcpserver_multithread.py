import signal
import socket
import sys
from concurrent.futures.thread import ThreadPoolExecutor
from uuid import uuid5, uuid4


class TCPThServer:
    """
     This is a tcp server application that uses thread pool
    """
    def __init__(self, host="",port=40000):
        self.server_port = int(port)
        self.bufsize=2048
        self.tcpServerSocket = socket.socket(family=socket.AF_INET, type= socket.SOCK_STREAM)
        self.host = host
        self.executor = ThreadPoolExecutor(5)
        self.futures = dict()

    def start(self):
        try:
            self.tcpServerSocket.bind((self.host, self.server_port))
            self.tcpServerSocket.listen(10)
            print("TCP Server is up and listening on port ", self.server_port)
        except OSError as ex:
            print(f"start failed: {ex}")
            sys.exit(1)

        while(True):
            try:
                conn, addr = self.tcpServerSocket.accept()
                future = self.executor.submit(self.process, conn,addr)
                client = Client(conn, addr, future)
                self.futures[client.get_id()] = client
            except OSError as ex:
                print(f"start failed: {ex}")
                sys.exit(1)

    def process(self,conn, addr):
        try:
            while True:

                message, clientAddress = conn.recvfrom(self.bufsize)
                host, port = addr
                print(f"message from client[{host}:{str(port)}]:{message.decode()}")
                msgtoClient = message.decode().upper()
                conn.send(str.encode(msgtoClient))
                if message == "exit":
                    print(f"Closed connection from client[{host}:{str(port)}]\n")
                    conn.close()
                    break
                elif not message:
                    print(f"Closed connection from client[{host}:{str(port)}]\n")
                    conn.close()
                    break

            print(f"Closed connection from client[{host}:{str(port)}]\n")
            conn.close()
        except:
            if conn!= None:
                conn.close()
                print(f"Closed connection from client[{host}:{str(port)}]\n")

    def stop(self):
        self.tcpServerSocket.close()
        print(f"server stopped!")
        sys.exit(0)

    def stop(self, signal, frame):
        self.tcpServerSocket.close()
        print(f"server stopped!")
        sys.exit(0)


class Client:
    def __init__(self, conn, addr,future):
        self.conn = conn
        self.addr = addr
        self.__id = str(uuid4())
        self.future = future

    def get_id(self):
        return self.__id

    def __str__(self):
        return "client id: " + self.get_id() + ", from:" + str(self.addr) + " ,Processing Status: " + self.future.result()


def run():

    server = None
    if len(sys.argv) == 3:
        server = TCPThServer(sys.argv[1], sys.argv[2])
    else:
        server = TCPThServer()
    signal.signal(signal.SIGINT, server.stop)

    if server is not None:
        server.start()


if __name__=="__main__":
    run()