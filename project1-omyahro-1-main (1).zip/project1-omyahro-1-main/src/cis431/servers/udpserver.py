import signal
import socket
import sys

class UDPServer:

    def __init__(self, host="",port=40000 ):
        self.server_port = int(port)
        self.bufsize=2048
        self.udpServerSocket = socket.socket(family=socket.AF_INET, type= socket.SOCK_DGRAM)
        self.host = host

    def start(self):
        self.udpServerSocket.bind((self.host, self.server_port))
        print("UDP Server is up and listening on port ", self.server_port)

        while(True):
                message,clientAddress = self.udpServerSocket.recvfrom(self.bufsize)
                print (f"message from client[{clientAddress}]:{message.decode()}")
                msgtoClient = message.decode().upper()
                self.udpServerSocket.sendto(str.encode(msgtoClient), clientAddress)
    def stop(self):
        self.udpServerSocket.close()
        print(f"server stopped!")
        sys.exit(0)

    def stop(self, signal, frame):
        self.udpServerSocket.close()
        print(f"server stopped!")
        sys.exit(0)


def run():

    server = None
    if len(sys.argv) == 2:
        server = UDPServer(sys.argv[1], sys.argv[2])
    else:
        server = UDPServer()
    signal.signal(signal.SIGINT, server.stop)

    if server!=None:
        server.start()



if __name__=="__main__":

    run()