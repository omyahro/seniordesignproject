import signal
import socket
import sys

from cis431.servers.tcpserver_multithread import TCPThServer


class TCPServer:

    def __init__(self, host="",port=40000):
        self.server_port = int(port)
        self.bufsize=2048
        try:
            self.tcpServerSocket = socket.socket(family=socket.AF_INET, type= socket.SOCK_STREAM)
        except :
            return None
        self.host = host


    def start(self):
        try:

            self.tcpServerSocket.bind((self.host, self.server_port))
            self.tcpServerSocket.listen(1)
            print("TCP Server is up and listening on port ", self.server_port)
        except OSError as ex:
            print(f"server bind failed: {ex.strerror}")
            exit(1)


        while(True):
            conn, addr = self.tcpServerSocket.accept()
            self.process(conn, addr)

    def process(self,conn, addr):
        try:
            while True:
                message, address = conn.recvfrom(self.bufsize)
                host,port = addr
                print(f"message from client[{host}:{str(port)}]:{message.decode()}")
                msgtoClient = message.decode().upper()
                conn.send(str.encode(msgtoClient))
                if message == "exit" :
                    print(f"Closed connection from client[{host}:{str(port)}]\n")
                    conn.close()
                    break
                elif not message:
                    print(f"Closed connection from client[{host}:{str(port)}]\n")
                    conn.close()
                    break

        except Exception as ex:
            print(f"Error: {ex}")
            if conn!= None:
                conn.close()
                print(f"Closed connection from client[{host}:{str(port)}]\n")

    def log(self, message):
        pass



    def stop(self):
        self.tcpServerSocket.close()
        print(f"server stopped!")
        sys.exit(0)

    def stop(self, signal, frame):
        self.tcpServerSocket.close()
        print(f"server stopped!")
        sys.exit(0)


def run():

    server = None
    if len(sys.argv) == 3:
        server = TCPServer(sys.argv[1], sys.argv[2])
    elif len(sys.argv) == 4 and "-tp" in sys.argv:
        server = TCPThServer(sys.argv[2], sys.argv[3])
    elif "-tp" in sys.argv:
        server = TCPThServer()
    else:
        server = TCPServer()
    signal.signal(signal.SIGINT, server.stop)

    if server!=None:
        server.start()

if __name__=="__main__":
    run()