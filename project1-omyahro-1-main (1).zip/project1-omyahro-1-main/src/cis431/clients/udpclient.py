import socket
import sys


class UDPClient():
    def __init__(self, server='', port=40000):
        self.server_port = int(port)
        self.bufsize=2048
        self.server_ipadder = server
        self.udpClientSocket = socket.socket(family=socket.AF_INET, type=socket.SOCK_DGRAM)


    def send(self):
        message = input("Send a message to  "+self.server_ipadder+":"+str(self.server_port)+":")
        self.udpClientSocket.sendto(str.encode(message), (self.server_ipadder, self.server_port))
        message, clientAddress = self.udpClientSocket.recvfrom(self.bufsize)
        print("message from Server:", message.decode())

def run():
    client = None

    if len(sys.argv) == 3:
        client = UDPClient(sys.argv[1], sys.argv[2])
    else:
        client = UDPClient()
    client.send()

if __name__=="__main__":
    # client = UDPClient('localhost', 40000)
    # client.send()
    run()
