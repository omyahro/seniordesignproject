import socket
import sys


class TCPClient():
    '''
     This is a simple TCP echo client
    '''
    def __init__(self, server='localhost', port=40000):
        '''
        __init__ method for TCPClient that initializes basic information about the server address and port
        :param server: ip address or hostname of the server. if not provided the default ip is localhost
        :param port: the port number of the server. the default port number is 40000
        '''
        self.server_port = int(port)
        self.server_addr = server
        self.bufsize=2048
        try:
            self.tcpclientSocket = socket.socket(family=socket.AF_INET, type=socket.SOCK_STREAM)
        except:
            return None


    def send(self, msg):
        '''
         This method will ask the user to type in a message to be sent to a remote server,
         If a message provided, it will send the messgae and stops the connection.
         This mehod will keep asking for user input till user enters exit
        :param msg: a string message to be sent only once and after which the connection closes.
        :return: None
        '''
        if self.tcpclientSocket is None:
            sys.exit(-1)
        try:
            self.tcpclientSocket.connect((self.server_addr, self.server_port))
        except OSError as ex:
            self.tcpclientSocket.close()
            s = None
            print(f"cannot connect: {ex}")
            sys.exit(1)

        if self.tcpclientSocket is None:
            print('could not open socket')
            sys.exit(1)
        try:

            while True:
                if msg is not None:
                    self.tcpclientSocket.sendto(str.encode(msg), (self.server_addr, self.server_port))
                    message, clientAddress = self.tcpclientSocket.recvfrom(self.bufsize)
                    print("message from Server:", message.decode())
                    self.tcpclientSocket.close()
                    break
                message = input("Send a message to  "+self.server_addr+":"+str(self.server_port)+":")
                if "exit" in message:
                    self.tcpclientSocket.close()
                    print("Bye!")
                    break
                elif not message:
                    self.tcpclientSocket.close()
                    print("Bye!")
                    break

                self.tcpclientSocket.sendto(str.encode(message), (self.server_addr, self.server_port))
                message, clientAddress = self.tcpclientSocket.recvfrom(self.bufsize)
                print("message from Server:", message.decode())
        except:
            self.tcpclientSocket.close()
            print("Bye!")


def run():
    '''
    This is a wrapper function for the tcpclient which setup.py uses
    if server address and port number are provided then it instantiates a tcpclient with provided information.
    Otherwise, default values are used.
    :return: None
    '''
    client = None
    # 34.123.123.53
    if len(sys.argv) == 3:
        client = TCPClient(sys.argv[1], sys.argv[2])
    else:
        client = TCPClient()
    client.send(None)



if __name__=="__main__":
    run()