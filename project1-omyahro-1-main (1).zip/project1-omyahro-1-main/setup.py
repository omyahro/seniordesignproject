from setuptools import setup, find_packages

setup(
    name='cis431',
    version='0.1.0',
    license='MIT',
    description='CIS431 examples',
    author='Ali Sazegar',
    packages=find_packages(where='src'),
    package_dir={'': 'src'},
    install_requires=['pytest-runner', 'pytest'],
    entry_points={
        'console_scripts': [
            'udpserver = cis431.servers.udpserver:run',
            'udpclient = cis431.clients.udpclient:run',
            'tcpclient = cis431.clients.tcpclient:run',
            'tcpserver = cis431.servers.tcpserver:run',
            'tcpserver2 = cis431.servers.tcpserver_multithread:run',
        ]
    },
)